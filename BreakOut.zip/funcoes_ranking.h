#ifndef FUNCOES_RANKING_H_INCLUDED
#define FUNCOES_RANKING_H_INCLUDED

void ranking ();
void exibir_ranking();

#endif // FUNCOES_RANKING_H_INCLUDED
