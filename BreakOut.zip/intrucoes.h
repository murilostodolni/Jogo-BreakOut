#ifndef INTRUCOES_H_INCLUDED
#define INSTRUCOES_H_INCLUDED

void instrucoes();

#endif // INTRUCOES_H_INCLUDED
