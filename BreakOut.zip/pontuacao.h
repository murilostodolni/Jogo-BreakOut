#ifndef PONTUACAO_H_INCLUDED
#define PONTUACAO_H_INCLUDED

void pontos_bloco(int num_blocos_destruidos);

#endif // PONTUACAO_H_INCLUDED
