#ifndef FUNCOES_DIVERSAS_H_INCLUDED
#define FUNCOES_DIVERSAS_H_INCLUDED

void perdeu_uma_vida ();
void finaliza_jogo(char opcao);
void retorna_menu();
void pausar_jogo();
int tamanho_string (char *nome);

#endif // FUNCOES_DIVERSAS_H_INCLUDED
