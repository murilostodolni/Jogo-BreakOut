#ifndef MOVIMENTO_BARRA_H_INCLUDED
#define MOVIMENTO_BARRA_H_INCLUDED

void movimento_barra (int passos, int mx);
void printa_barra ();

#endif // MOVIMENTO_BARRA_H_INCLUDED
