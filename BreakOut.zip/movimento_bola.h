#ifndef MOVIMENTO_BOLA_H_INCLUDED
#define MOVIMENTO_BOLA_H_INCLUDED

void bola_dos_lados (int x, int xd);
void bola_em_cima (int y, int yd);
void bola_na_barra (int xd);
void apaga_rastro_bola ();
void printa_bola();


#endif // MOVIMENTO_BOLA_H_INCLUDED
