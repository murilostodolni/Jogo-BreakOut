#ifndef FUNCOES_EXTERNAS_H_INCLUDED
#define FUNCOES_EXTERNAS_H_INCLUDED

void gotoxy();
void textcolor();
void hidecursor();

#endif // FUNCOES_EXTERNAS_H_INCLUDED
