#ifndef DESENHOS_H_INCLUDED
#define DESENHOS_H_INCLUDED

void nome_breakout ();
void nome_ranking ();
void nome_gameover ();
void nome_voceganhou ();
void inicia_nome_breakout();
void sair_do_jogo();

#endif // DESENHOS_H_INCLUDED
